from django.urls import path
from .views import product_list, add_product, edit_product, delete_product, record_sale, generate_sales_report

urlpatterns = [
    path('', product_list, name='product_list'),
    path('add/', add_product, name='add_product'),
    path('edit/<int:pk>/', edit_product, name='edit_product'),
    path('delete/<int:pk>/', delete_product, name='delete_product'),
    path('sale/<int:pk>/', record_sale, name='record_sale'),
    path('sales_report/', generate_sales_report, name='sales_report'),
]