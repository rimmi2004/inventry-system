from django.shortcuts import render, redirect
from .models import Product, StockTransaction, Sale
from .forms import ProductForm
from django.db.models import Sum
from django.utils import timezone
from datetime import timedelta

def product_list(request):
    products = Product.objects.all()
    low_stock_threshold = 5
    low_stock_products = products.filter(stock_quantity__lt=low_stock_threshold)
    return render(request, 'product_list.html', {'products': products, 'low_stock_products': low_stock_products})

def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            product = form.save()
            return redirect('product_list')
    else:
        form = ProductForm()
    return render(request, 'add_product.html', {'form': form})

def edit_product(request, pk):
    product = Product.objects.get(pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            return redirect('product_list')
    else:
        form = ProductForm(instance=product)
    return render(request, 'edit_product.html', {'form': form})

def delete_product(request, pk):
    product = Product.objects.get(pk=pk)
    product.delete()
    return redirect('product_list')

def record_sale(request, pk):
    product = Product.objects.get(pk=pk)
    if request.method == 'POST':
        quantity = int(request.POST.get('quantity'))
        if quantity <= product.stock_quantity:
            product.stock_quantity -= quantity
            product.save()
            Sale.objects.create(product=product, quantity=quantity)
            StockTransaction.objects.create(product=product, quantity=quantity, transaction_type='sale')
            return redirect('product_list')
    return render(request, 'record_sale.html', {'product': product})

def generate_sales_report(request):
    today = timezone.now()
    last_30_days = today - timedelta(days=30)
    total_sales = Sale.objects.filter(timestamp__gte=last_30_days).aggregate(Sum('quantity'))['quantity__sum'] or 0
    most_sold_product = Sale.objects.filter(timestamp__gte=last_30_days).values('product').annotate(total=Sum('quantity')).order_by('-total').first()
    return render(request, 'sales_report.html', {'total_sales': total_sales, 'most_sold_product': most_sold_product})