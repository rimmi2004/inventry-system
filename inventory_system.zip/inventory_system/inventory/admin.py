from django.contrib import admin
from .models import Product, StockTransaction, Sale

admin.site.register(Product)
admin.site.register(StockTransaction)
admin.site.register(Sale)